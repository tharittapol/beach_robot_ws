#include <Arduino.h>
#include <string.h>
#include <stdlib.h>

#include "encoder.h"
#include "encoder_config.h"
#include "buzzer.h"

struct LineReader {
  size_t n = 0;
  bool read(Stream &s, char *buf, size_t cap) {
    while (s.available()) {
      char c = (char)s.read();

      // filter noise (optional but recommended)
      if (c == '\r') continue;
      if (c != '\n' && (c < 32 || c > 126)) continue;

      if (c == '\n') { buf[n] = '\0'; n = 0; return true; }
      if (n + 1 < cap) buf[n++] = c;
      else n = 0; // overflow -> reset
    }
    return false;
  }
};
static LineReader lr_cmd;

// ส่งข้อมูลไป MAIN ผ่าน UART2 (Serial2)
static uint32_t last_upd_ms = 0;
static uint32_t last_tx_ms  = 0;

static constexpr uint32_t UPDATE_MS = 10; // 100 Hz update
static constexpr uint32_t TX_MS     = 20; // 50 Hz tx (แนะนำเริ่มที่นี่)

// ถ้าจะดัน 100Hz จริง ๆ แนะนำเพิ่ม baud เป็น 230400/460800 ทั้งสองฝั่ง
// และยังควรเช็ค availableForWrite กันบล็อกด้วย

static void pump_cmd_from_main() {
  static char cmdline[64];
  if (lr_cmd.read(Serial2, cmdline, sizeof(cmdline))) {
    if (strncmp(cmdline, "B:", 2) == 0) {
      float duration_sec = atof(cmdline + 2);
      set_buzzer_duration(duration_sec);
    }
  }
}

static void tx_encoder_to_main() {
  EncoderData e = encoder_get();

  // กันไม่ให้ printf บล็อก: ถ้า buffer ไม่พอ ให้ข้ามเฟรมนี้ไปก่อน
  // (ค่าที่ต้องส่ง 1 บรรทัดประมาณ >100 bytes)
  const int need = 160;
  if (Serial2.availableForWrite() < need) return;

  Serial2.printf(
    "{\"enc_vel\":[%.6f,%.6f,%.6f,%.6f],\"wheel_cnt\":[%lld,%lld,%lld,%lld],\"t_ms\":%lu}\n",
    e.w[0].vel_mps, e.w[1].vel_mps, e.w[2].vel_mps, e.w[3].vel_mps,
    (long long)e.w[0].count, (long long)e.w[1].count, (long long)e.w[2].count, (long long)e.w[3].count,
    (unsigned long)millis()
  );
}

void setup() {
  Serial.begin(115200);
  delay(200);

  Serial2.begin(ENC_UART_BAUD, SERIAL_8N1, ENC_UART_RX_PIN, ENC_UART_TX_PIN);
  // เพิ่ม buffer ลดโอกาสบล็อก/overflow (มีใน ESP32 Arduino)
  Serial2.setTxBufferSize(1024);
  Serial2.setRxBufferSize(256);

  encoder_begin();
  last_upd_ms = millis();
  last_tx_ms  = millis();

  buzzer_begin();
}

void loop() {
  const uint32_t now = millis();

  // 1) non-blocking RX from MAIN
  pump_cmd_from_main();
  handle_buzzer();

  // 2) update encoder @100Hz
  if (now - last_upd_ms >= UPDATE_MS) {
    const float dt_s = (now - last_upd_ms) / 1000.0f;
    last_upd_ms = now;
    encoder_update(dt_s);
  }

  // 3) tx to MAIN @50Hz (เริ่ม 50Hz ก่อนให้ชัวร์)
  if (now - last_tx_ms >= TX_MS) {
    last_tx_ms = now;
    tx_encoder_to_main();
  }
}